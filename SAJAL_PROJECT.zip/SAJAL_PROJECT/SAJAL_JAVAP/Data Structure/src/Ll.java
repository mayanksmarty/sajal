public class Ll {

    Node head;

    class Node {
        int data;

        Node next;

        Node(int info) {
            data = info;
            next = null;
        }
    }

    public void insert(int info) {
        Node newNode = new Node(info);

        if (head == null) {
            head = newNode;

        } else {
            Node last;
            last = head;
            while (last.next != null) {
                last = last.next;

            }
            last.next = newNode;
        }
    }

    public void insertAtBeg(int info) {
        Node newNode = new Node(info);
        if (head == null) {
            head = newNode;

        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void remove(int info) {
        Node curr = head, prev = null;
        while (curr != null) {
            if (curr.data == info && curr == head) {
                head = head.next;
            }
            else if (curr.data == info)
                prev.next = curr.next;


            prev = curr;
            curr = curr.next;
        }
        }





    public void removeIndex(int index) {
        int c = 0;
        Node prev = null;
        Node curr = head;
        while (curr != null) {
            if (index == 0) {
                head = head.next;
                break;
            } else if (index == c) {
                prev.next = curr.next;
            }
            c++;
            prev = curr;
            curr = curr.next;
        }
    }

    public void printList() {
        Node t = head;
        System.out.print("LinkedList: ");
        while ( t!= null) {
            System.out.print(t.data + " ");
            t = t.next;
        }
    }


    public static void main(String[] args) {
        Ll l = new Ll();
        l.insert(5);
        l.insert(6);
        l.insertAtBeg(7);
        l.insert(8);
        l.printList();
        l.remove(5);
        l.insert(9);
        l.insert(10);

        l.printList();
       l.remove(10);
        l.remove(7);
        l.removeIndex(2);
        l.printList();
    }
}

