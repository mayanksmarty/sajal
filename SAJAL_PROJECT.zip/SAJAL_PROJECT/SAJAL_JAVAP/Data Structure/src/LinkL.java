import java.util.Objects;
import java.util.Scanner;
public class LinkL{
    Node head=null;
 //   int size=0;
    class Node {
        Object obj;
        Node next;

        Node() {
        }

        public Node(Object obj) {
            this.obj = obj;
            next=null;
        }

    }
    void insert(Object obj)
    {
        Node newNode=new Node(obj);
        if(head==null)
        {
            head=newNode;
          //  size=size+1;
        }
        else
        {
            Node curr=head;
            while(curr.next!=null){
                curr=curr.next;
            }
        curr.next=newNode;
         //   size=size+1;

        }

    }
    void insertAfter(Object curr,Object pre) {

    Node newNode= new Node(curr);
Node currNode=head;
Node Prev=null;

    while(!(currNode.obj.equals(pre)) && !(currNode.equals(null)))
    {
        Prev=currNode;
        currNode=currNode.next;

    }
    newNode.next=currNode.next;
    currNode.next=newNode;
    //size=size+1;
    }

void insertAfter(Object obj,int index) {

    if (index < 0) {
        if (head == null) {
            System.out.println("There is no Linked List");
            System.out.println("Would You Like To Create a New Node?\nIf Yes press Y Otherwise N");
            Scanner ob = new Scanner(System.in);
            String str = ob.next();
            switch (str) {
                case "Y":
                    Node newNode = new Node(obj);
                    // size=size+1;
                    break;
                case "N":
                    System.out.println("Thank You");
                    break;
                default:
                    System.out.println("You Entered Wrong Text");

            }
        }
        else {
            System.out.println("Your Index is Invalid");
        }
    } else {
        int c = 0;
        Node curr = head;
        Node prev = null;
        Node newNode = new Node(obj);

        while (curr != null) {
            if (index == c && curr.next == null) {
                curr.next = newNode;
                break;
            } else if (index == c) {
                newNode = curr.next;
                curr.next = newNode;
                break;
            } else {
                c++;
                curr = curr.next;

            }
        }
    }



    }



void remove(Object obj) {

    Node prev = null;
    Node t = head;
    if(head==null)
        System.out.println("There is No Linked List");
   else if(head.obj.equals (obj))
    {
        head = head.next;
    }
    else {
        while ( !(t.equals(null)) && !((t.obj).equals(obj))) {
            prev = t;
            t = t.next;

        }
        if(t.obj.equals(obj)) {
            prev.next = t.next;
           //size = size - 1;
        }
    }
}
boolean removeindex(int index) {
boolean flag=false;
    if (index < 0) {
        System.out.println("node cannot be remove becz your index is invalid");

    }
    else if (index == 0) {
        head = head.next;
        flag=true;
    }
    else {
        Node prev = null;
        Node curr = head;
        int c = 1;
        while (curr != null) {
            prev = curr;
            curr = curr.next;
            if (c == index) {

                prev.next = curr.next;
                flag=true;

                break;

            }
            else {
                c++;
            }
        }

    }
    return flag;
}

boolean search(Object obj)
{
    Node t=head;
    while(t!=null && !((t.obj).equals(obj)))
    {
        t=t.next;

    }
    if(t.obj.equals(obj))
    {
        return true;
    }
    else
    {
        return false;
    }
}



void display()
{
    Node t=head;
    while(t!=null)
    {
        System.out.println(t.obj);
        t=t.next;
    }

}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkL linkL = (LinkL) o;
        return Objects.equals(head, linkL.head);
    }



    public static void main(String[] args) {
              Student sajal=new Student(1614313067,"Sajal");
              Student p=new Student(1614313068,"mittal");
              Student c=new Student(1614313069,"Amar");
              sajal.setCourse("Core java");
              p.setCourse("Core Java");
              c.setCourse("Core java");
              Student.setCountry("India");

              LinkL l1=new LinkL();
              l1.insert(sajal);
              l1.insert(p);
              l1.insert(c);
              l1.display();
            boolean b=  l1.search(sajal);
            if(b==true)
                System.out.println("data found");
            else
                System.out.println("data not found");
         boolean bb= l1.removeindex(0);
         System.out.println(bb);
         l1.display();
         l1.remove(p);
         l1 .display();
         l1.insertAfter(p,c);
        System.out.println("**********");
        l1.display();
        System.out.println("####################");
        l1.insertAfter(sajal,1);
        l1.display();
        System.out.println("##############");
        Student t=new Student(1614313070,"tejas");
        l1.insertAfter(t,5);// ISS CASE KO DEKNA HAI//




    }



}
