public class Listmain{
    public static void main(String[] args) {

LinkList l1=new LinkList();
LinkList.Node a=l1. new Node(0);
LinkList.Node b=l1. new Node(1);
LinkList.Node c=l1. new Node(2);
LinkList.Node d=l1. new Node(3);
l1.addBegin(a);
l1.addLast(b);
l1.addLast(c);
l1.addLast(d);
l1.remove(3);
l1.showList();

    }
}
