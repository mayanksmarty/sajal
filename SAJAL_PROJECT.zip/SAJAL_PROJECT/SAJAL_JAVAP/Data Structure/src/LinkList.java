
public class LinkList {

    Node head;
public  class Node {

        int data;
        Node next;

        Node()
        {

        }
        Node(int info)
        {
            data=info;
            next=null;
        }
    }
   public void addBegin(Node h)
   {
       if(head==null)
       {
           head=h;
       }
       else
       {
           h.next=head;
           head=h;
       }
   }
   public void addLast(Node h)
   {

       if(head==null)
       {
           head=h;
       }
       Node i=head;
       while(i.next!=null)
       {
           i=i.next;
       }
       i.next=h;
       h.next=null;



   }

   public void addMiddle(Node h,int n) {
       Node i = head;
       while (h.data != n) {
           i = i.next;

       }
       h.next = i.next;
       i.next = h;

    }
    public void remove(int  a){
        Node prev=null;
         Node cur=head;
        while(cur!=null)
        {

            if(cur.data==a && cur==head)
            {
               head=head.next;
               break;
            }
            else if(cur.data==a)
            {
                prev.next=cur.next;
                break;
            }
            prev=cur;
            cur=cur.next;

        }

    }
    public void search(int a)
    {
        Node t=head;
        while(t!=null)
        {
            if(t.data==a) {
                System.out.println("Yes Element Found");
            break;
            }

            t=t.next;



        }



    }
public void showList()
{
    Node t=head;
    while(t!=null)
    {
        System.out.println(t.data);
        t=t.next;
    }
}


}
