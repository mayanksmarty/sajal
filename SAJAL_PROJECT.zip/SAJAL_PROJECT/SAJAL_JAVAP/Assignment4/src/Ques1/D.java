package Ques1;

public class D {

    void m()
    {
        int data = 50 / 0;
    }

    void n()
    {
        m();
    }

    void p()
    {
        try {
            n();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[])
    {
        D obj = new D();
        obj.p();
        System.out.println("Hii How Are You");
    }
}
