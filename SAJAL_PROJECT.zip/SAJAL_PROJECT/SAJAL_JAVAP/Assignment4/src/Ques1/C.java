package Ques1;

public class C {


    public static void main(String[] args) {

        String str=null;
        try {
            int i = Integer.parseInt("135 ");
            System.out.println(str.length());
        }
        finally {
            System.out.println("Hello Shourya");
        }
    }
}
