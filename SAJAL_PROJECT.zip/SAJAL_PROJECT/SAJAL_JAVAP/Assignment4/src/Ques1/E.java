package Ques1;

public class E {
    public static void main(String args[]){
        try{
            int p=Integer.parseInt("123");
            try{
                int b =15/0;
                System.out.println(b);
            }
            catch(ArithmeticException e)
            {
                System.out.println(e);
            }

            try{
                int a[]=new int[5];
                a[5]=4;
            }
            catch(ArrayIndexOutOfBoundsException e)
            {
                System.out.println(e);
            }

            System.out.println("All inner exceptions handled");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("End of Program");
    }
}
