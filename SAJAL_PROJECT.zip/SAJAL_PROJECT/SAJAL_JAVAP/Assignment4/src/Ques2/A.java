package Ques2;

public class A {
    public static void main(String[] args)throws NullPointerException {

        int balance=5000;
        int withdrawAmount=6000;
        if(balance < withdrawAmount)
        {
            throw new ArithmeticException("Insufficient Balance");
            balance=balance-withdrawAmount;
            System.out.println("Transaction Succcessfully completed");
            System.out.println("Program continue");

        }
    }


        }









