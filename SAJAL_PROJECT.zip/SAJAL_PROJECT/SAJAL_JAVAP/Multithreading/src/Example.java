public class Example implements Runnable {

    @Override
    public void run() {
        System.out.println("");
    }

    public static void main(String[] args) {
        Example runnable = new Example();


    }
}
