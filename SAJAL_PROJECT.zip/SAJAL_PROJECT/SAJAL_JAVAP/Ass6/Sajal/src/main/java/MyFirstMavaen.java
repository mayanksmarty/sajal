public class MyFirstMavaen {
    public static void main(String[] args) {
        System.out.println("hii mai hu sajal");
    }
}
