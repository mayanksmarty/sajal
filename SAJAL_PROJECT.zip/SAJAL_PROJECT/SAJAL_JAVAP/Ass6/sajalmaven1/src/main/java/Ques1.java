public class Ques1 {
    public static void main(String[] args) {
        System.out.println("hello All");
        int a=10;
        int b=20;
        int c=add(a,b);
        System.out.println("Addition of A and B are "+c);
    }
static int add(int x,int y)
{
    return(x+y);
}


}


