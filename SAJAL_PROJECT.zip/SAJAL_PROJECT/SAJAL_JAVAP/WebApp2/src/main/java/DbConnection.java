//import java.sql.Connection;
//
//public class DbConnection{
//    public static Connection createconnection(){
//        Connection con = null;
//        String url ="";
//        String username = "sh";
//        String password = "sh";
//        try {
//            try{
//                Class.forName("oracle.jdbc.driver.OracleDriver");
//
//            }
//            catch(ClassNotFoundException e) {
//                e.printStackTrace();
//            }
//
//        }
//    }
//}
