import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/bac.html")
public class Test extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        //out.println("<html> <head> <title> Welcome Here </title> </head> <body> <h1> Successfully Login </h1>  <h3> Thank You for Visiting here </h3></body> </html>");

        String name = req.getParameter("username");
        out.println(name);
       /* String p = req.getParameter("pass");
        String age = req.getParameter("age");

        String loginId = (String)req.getAttribute("username");
        //String usr=req.getParameter("username");

        out.println("Login Id " + loginId + "<br>");
        out.println("name " + name);*/






        /*resp.setContentType("text/html");
        PrintWriter pout=resp.getWriter();
        pout.println("<html> <head> <title> Welcome Here </title> </head> <body> <h1> we will provide complete registration details </h1> </body> ");
*/
    }

}
