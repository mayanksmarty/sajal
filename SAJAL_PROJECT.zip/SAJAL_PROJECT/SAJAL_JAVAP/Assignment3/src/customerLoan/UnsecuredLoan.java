package customerLoan;

import java.time.LocalDate;

abstract public class UnsecuredLoan extends Loan {


    public UnsecuredLoan(double loanAmount, double roi, int tenure, String loanType, int repaymentFrequency, double monthlyincome) {
        super(loanAmount, roi, tenure, loanType, repaymentFrequency, monthlyincome);
    }
}


