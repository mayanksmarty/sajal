package customerLoan;

import java.util.*;

public class Bank implements maker,checker
{

    ArrayList<Loan> loans = new ArrayList<>();
    ArrayList<Customer> cust = new ArrayList<>();
    HashMap<Integer,Loan> loanmap = new HashMap<>();
    static int loanCount;
    static int customerCount=0;
    int number = 0;



    @Override
    public int applyHomeLoan(double loanAmount, double roi, int tenure,
                         String typeOfLoan, int repaymentFrequency,
                         double monthlyIncome, String builderName,
                         int propertySize, double propertyValue) {
        Loan loan = new HomeLoan(loanAmount,roi,tenure,typeOfLoan,
                repaymentFrequency,
                monthlyIncome,builderName,propertySize,propertyValue);
        loans.add(loan);
        loanmap.put(loan.getLoanId(),loan);

        return loans.get(number++).getLoanId();
    }



        @Override
    public int applyVehicleloan(double loanAmount, double roi, int tenure,
                         String typeOfLoan, int repaymentFrequency, int noOfInstallments, double monthlyIncome, String vehicleCategory, String vehiclemodelNo,
                         String manufacturer, int yearOfManufacture, double assetValue) {
        Loan loan=new VehicleLoan(loanAmount,roi,tenure,typeOfLoan,repaymentFrequency
                ,monthlyIncome,vehicleCategory,  vehiclemodelNo,  manufacturer,
                yearOfManufacture,  assetValue);

        loans.add(loan);
        return loans.get(number++).getLoanId();
    }

    @Override
    public int applyPersonalLoan(double loanAmount, double roi,
                         int tenure,String typeOfLoan,
                         int repaymentFrequency, int noOfInstallments, double monthlyIncome,
                         String qualification, double workExperience) {
       Loan loan=new PersonalLoan(loanAmount,  roi,
               tenure, typeOfLoan,  repaymentFrequency,
               monthlyIncome,  qualification,  workExperience);
        loans.add(loan);

        return loans.get(number++).getLoanId();

    }

    @Override
    public String trackLoanStatus(int loanApplicationId) {


return "sa";
    }

    @Override
    public void getAllactiveloanDetails() {

    }

    @Override
    public void getloanDetails(long loanAccountNumber) {

    }

    @Override
    public void approveRejectLoan(int loanApplicationId) {

    }

    @Override
    public void getAllActiveLoanDetails() {

    }

    @Override
    public void getLoanDetails(long loanAccountNumber) {

    }

    @Override
    public boolean removeLoanAccount(long loanAccountNumber) {
        return false;
    }
}
