package customerLoan;

public interface checker {

  public void approveRejectLoan(int loanApplicationId);

    public  void getAllActiveLoanDetails();

    public  void getLoanDetails(long loanAccountNumber);
    public  boolean removeLoanAccount(long loanAccountNumber);
}
