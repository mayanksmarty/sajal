package customerLoan;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

 abstract public class Loan {

     private double monthlyExpense;
    private int loanId;
    static int i;
    private String loanType;
    private double loanAmount;
    private int tenure;
    private double roi;
    private double emiPerMonth;

    private LocalDate loanDisbursalDate= LocalDate.of(2019,02,01);
    private LocalDate dueDate;
    private LocalDate repaymentDate;
    private double maxEligibleLoanAmount;
     enum LoanStatus{
         approved,pending,reject;

     }
     LoanStatus loanStatus;

     public LoanStatus getLoanStatus() {
         return loanStatus;
     }

     public void setLoanStatus(LoanStatus loanStatus) {
         this.loanStatus = loanStatus;
     }

     public Loan(double loanAmount, double roi, int tenure, String loanType, int repaymentFrequency, double monthlyincome ) {
         this.loanAmount = loanAmount;
         this.loanId=++i;
         this.tenure = tenure;
         this.roi = roi;
         this.loanType=loanType;
         this.repaymentFrequency=repaymentFrequency;
         this.monthlyIncome=monthlyincome;
         this.loanStatus=LoanStatus.pending;
     }

     public void setLoanId(int loanId) {
         this.loanId = loanId;
     }

     public LocalDate getDueDate() {
         return dueDate;
     }

     @Override
     public String toString() {
         return "Loan{" +
                 "monthlyExpense=" + monthlyExpense +
                 ", loanId=" + loanId +
                 ", loanType='" + loanType + '\'' +
                 ", loanAmount=" + loanAmount +
                 ", tenure=" + tenure +
                 ", roi=" + roi +
                 ", emiPerMonth=" + emiPerMonth +
                 ", loanDisbursalDate=" + loanDisbursalDate +
                 ", dueDate=" + dueDate +
                 ", repaymentDate=" + repaymentDate +
                 ", maxEligibleLoanAmount=" + maxEligibleLoanAmount +
                 ", repaymentFrequency=" + repaymentFrequency +
                 ", monthlyIncome=" + monthlyIncome +
                 '}';
     }

     public void setDueDate(LocalDate dueDate) {
         this.dueDate = dueDate;
     }

     public LocalDate getRepaymentDate() {
         return repaymentDate;
     }

     public void setRepaymentDate(LocalDate repaymentDate) {
         this.repaymentDate = repaymentDate;
     }

     public int getRepaymentFrequency() {
         return repaymentFrequency;
     }

     private  int repaymentFrequency;
    private double monthlyIncome;

     public double getMonthlyExpense() {
         return monthlyExpense;
     }

     public void setMonthlyExpense(double monthlyExpense) {
         this.monthlyExpense = monthlyExpense;
     }






     public void setLoanType(String loanType) {
         this.loanType = loanType;
     }

     Scanner obj=new Scanner(System.in);
    public double getEmiPerMonth() {
        return emiPerMonth;
    }

    public void setEmiPerMonth(double emiPerMonth) {
        this.emiPerMonth = emiPerMonth;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }


    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public int getLoanId() {
        return loanId;
    }



    public String getLoanType() {
        return loanType;
    }



    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public int getTenure() {
        return tenure;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public double getRoi() {
        return roi;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }


    public LocalDate getLoanDisbursalDate() {
        return loanDisbursalDate;
    }

    public void setLoanDisbursalDate(LocalDate loanDisbursalDate) {
        this.loanDisbursalDate = loanDisbursalDate;
    }

    public void setMaxEligibleLoanAmount(double maxEligibleLoanAmount) {
        this.maxEligibleLoanAmount = maxEligibleLoanAmount;
    }

    public double getMaxEligibleLoanAmount() {
        return maxEligibleLoanAmount;
    }

    public void setRepaymentFrequency(int repaymentFrequency) {
        this.repaymentFrequency = repaymentFrequency;
    }
    public void calculateEmi()
    {
        int t=(int) tenure* repaymentFrequency;
        double r=roi/100;
        double power=Math.pow((1 + r/repaymentFrequency), t);
        double residual=0;
        emiPerMonth=((loanAmount*r/repaymentFrequency)-((residual*r/repaymentFrequency)/power))/(1-1/power);

        setEmiPerMonth(emiPerMonth);
    }


    void generateRepaymentSchedule()
    {
        double interestCompo;
        double openBalance=loanAmount;

        System.out.println("openbalance "+openBalance);
        double principalCompo=0;
        double r=roi/100;
        int t= tenure* repaymentFrequency;
        System.out.println(t);

        double power=Math.pow((1 + r/repaymentFrequency), t);
        double residual=0;

        double installment=((loanAmount*r/repaymentFrequency)-((residual*r/repaymentFrequency)/power))/(1-1/power);

        System.out.println(installment);
        double n=tenure*repaymentFrequency;
        //LocalDate duDate=
        for(int i=1;i<=n;i++)
        {

            System.out.println();
            System.out.println();System.out.println();System.out.println();System.out.println();System.out.println();




            System.out.println("Installment No: " +(100+i));
            openBalance-=principalCompo;
            System.out.println("Opening Balance: "+openBalance);
            System.out.println("Insatllment: "+installment);
            interestCompo=(roi/1200)*openBalance;
            System.out.println("Interest Component: "+interestCompo);
            principalCompo=installment-interestCompo;
            System.out.println("Principal Component: "+principalCompo);

        }
    }

    public LocalDate calculateDueDate(){

        System.out.println("Enter the last repayment date in dd/mm/yyyy format");
        String repayDate=obj.next();
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate lastRepaymentDate=LocalDate.parse(repayDate,formatter);
        LocalDate dueDate=lastRepaymentDate.plusMonths(1);
        return(dueDate);



    }

     void calculateLatePenalty()
    {

        LocalDate repaymentDate=LocalDate.now();

        LocalDate dueDate=calculateDueDate();
        if(repaymentDate.equals(dueDate))
        {
            System.out.println("There is no penalty as your payment is in time \nThank You");

        }
        else
        {
            double n=85.65;
            long noOfDaysBetween = ChronoUnit.DAYS.between(dueDate, repaymentDate);

            double penalty=n*noOfDaysBetween;
            System.out.println("Your penalty, due to late payment is "+penalty);

        }



    }
    public void calculateEligibleLoanAmount()
    {
        //double monthlyIncome=getMonthlyIncome();
        double r=getRoi()/1200;
     //  double e=0.5*(monthlyIncome-0.2*monthlyIncome);
       double e = (((getMonthlyIncome() - getMonthlyExpense())*0.5) -  (getMonthlyIncome()*0.2));
        double t=7*12;
        double pow1=Math.pow((1+r),t);
        double max= (e * (pow1 - 1 ))/ (r * pow1);
        setMaxEligibleLoanAmount(max);
        System.out.println(max);
    }
}
