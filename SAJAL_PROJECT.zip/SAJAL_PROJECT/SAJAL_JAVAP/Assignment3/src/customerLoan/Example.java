package customerLoan;

public class Example {
    public static void main(String[] args) {



    }
}
