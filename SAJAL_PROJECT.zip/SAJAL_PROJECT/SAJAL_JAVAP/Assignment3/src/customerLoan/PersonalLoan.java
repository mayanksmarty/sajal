package customerLoan;

import java.time.LocalDate;

public class PersonalLoan extends UnsecuredLoan {
    String qualification;
    double workExperience;

    public PersonalLoan(double loanAmount, double roi, int tenure, String loanType,
                        int repaymentFrequency, double monthlyincome,String qualification,
                        double  workExperience) {
        super(loanAmount, roi, tenure, loanType, repaymentFrequency, monthlyincome);
        this.qualification=qualification;
        this.workExperience=workExperience;
    }


    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public double getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(double workExperience) {
        this.workExperience = workExperience;
    }
}
