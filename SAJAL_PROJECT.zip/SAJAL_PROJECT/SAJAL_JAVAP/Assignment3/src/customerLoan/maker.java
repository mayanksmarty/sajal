package customerLoan;

public interface maker {

public int  applyHomeLoan(double loanAmount,double roi,int tenure,String typeOfLoan,
               int repaymentFrequency,
               double monthlyIncome,String builderName,
               int propertySize,double propertyValue);

public int applyVehicleloan(double loanAmount,double roi,
              int tenure,String typeOfLaon,int repaymentfrequency,
              int noOfinstallments,double monthlyincome,String vehicleCategory,
        String vehiclemodelNo,
        String manufacturer,
        int yearOfManufacture,
        double assetValue);
public int applyPersonalLoan(double loanAmount,double roi,
                     int tenure,String typeOfLaon,int repaymentfrequency,
                     int noOfinstallments,double monthlyincome,String qualification,
                             double workExperience);

    public String trackLoanStatus(int loanApplicationid);
    public   void getAllactiveloanDetails();
    public   void getloanDetails(long loanAccountNumber);

}
