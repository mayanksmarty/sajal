package customerLoan;

import customerLoan.Bank;
import customerLoan.HomeLoan;
import customerLoan.Loan;

import java.util.HashMap;

public class testMain {

    public static void main(String[] args) {

        Customer c1=new Customer(1,"Sajal");
        Customer c2=new Customer(1,"Sajal");
        Customer c3=new Customer(1,"Sajal");
        Customer cc4=new Customer(1,"Sajal");
        Customer c5=new Customer(1,"Sajal");
        Bank b=new Bank();




//        Loan l2=new HomeLoan(2000000,10,12,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l3=new HomeLoan(3000000,10,10,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l4=new HomeLoan(1500000,10,16,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l5=new HomeLoan(1800000,10,10,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l6=new HomeLoan(1400000,10,18,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l7=new HomeLoan(1300000,10,8,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l8=new HomeLoan(5000000,10,10,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l9=new HomeLoan(3000000,10,10,"Home Loan",12,80000,"ash Sh",200,4000000);
//        Loan l10=new HomeLoan(1000000,10,10,"Home Loan",12,80000,"ash Sh",200,4000000);

        Bank b1=new Bank();

        b.applyHomeLoan(1000000,12,10,"Home Loan",
                12,80000,"ash",
                200,4000000);

        b.applyHomeLoan(1000000,12,10,"Home Loan",
                12,80000,"ash",
                200,4000000);
        b.applyHomeLoan(1000000,12,10,"Home Loan",
                12,80000,"ash",
                200,4000000);
        b.applyHomeLoan(1000000,12,10,"Home Loan",
                12,80000,"ash",
                200,4000000);

    }


}
