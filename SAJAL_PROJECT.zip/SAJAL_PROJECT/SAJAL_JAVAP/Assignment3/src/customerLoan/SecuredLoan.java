package customerLoan;

import java.time.LocalDate;
import java.util.Scanner;

abstract public class SecuredLoan extends Loan {

    Scanner sc = new Scanner(System.in);

    public SecuredLoan(double loanAmount, double roi, int tenure,
                       String typeOfLoan, int repaymentFrequency, double monthlyIncome) {
        super(loanAmount,roi,tenure,typeOfLoan,repaymentFrequency,monthlyIncome);
    }


    double loanToValueRatio() {
        return 0;
    }
}
