package customerLoan;

import java.time.LocalDate;

public class VehicleLoan extends SecuredLoan {

  public  String vehicleCategory;
    public String vehiclemodelNo;
    public String manufacturer;
    public  int yearOfManufacture;
    public double assetValue;



    public VehicleLoan(double loanAmount, double roi, int tenure, String typeOfLoan, int repaymentFrequency,
                       double monthlyIncome, String vehicleCategory,
                       String vehiclemodelNo, String manufacturer,
                       int yearOfManufacture, double assetValue) {
        super(loanAmount,roi,tenure,typeOfLoan,repaymentFrequency,monthlyIncome);
        this.vehicleCategory=vehicleCategory;
        this.vehiclemodelNo=vehiclemodelNo;
        this.manufacturer=manufacturer;
        this.yearOfManufacture=yearOfManufacture;
        this.assetValue=assetValue;
    }


    public String getVehicleCategory() {
        return vehicleCategory;
    }

    public void setVehicleCategory(String vehicleCategory) {
        this.vehicleCategory = vehicleCategory;
    }

    public String getVehiclemodelNo() {
        return vehiclemodelNo;
    }

    public void setVehiclemodelNo(String vehiclemodelNo) {
        this.vehiclemodelNo = vehiclemodelNo;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(int yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public double getAssetValue() {
        return assetValue;
    }

    public void setAssetValue(double assetValue) {
        this.assetValue = assetValue;
    }

    @Override
    double loanToValueRatio() {
        return (getLoanAmount()/getAssetValue());
    }
}

