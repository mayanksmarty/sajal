//package customerLoan;
//
//import java.time.LocalDate;
//import java.util.Scanner;
//
//public class Test {
//
//    public static void main(String[] args) {
//
//
//        Scanner sc = new Scanner(System.in);
//
//
//        System.out.println("Please Enter Loan Type");
//        String s = sc.nextLine();
//
//        System.out.println("Please Enter Loan id");
//        int id = sc.nextInt();
//
//        System.out.println("Please Enter Loan Amount");
//        double d = sc.nextDouble();
//
//
//        System.out.println("Enter Your Monthly Income");
//        int income = sc.nextInt();
//
//        System.out.println("Enter monthly expense:- ");
//        int expense = sc.nextInt();
//
//        System.out.println("Enter the Tenure");
//        int tenure = sc.nextInt();
//
//        System.out.println("Enter Rate Of Interest");
//        double roi = sc.nextDouble();
//
//        System.out.println("Enter Repayment Frequency");
//        int fr = sc.nextInt();
//
//        LocalDate da = LocalDate.now();
//
//
//        if (s.equalsIgnoreCase("Home Loan") ){
//
//
//            HomeLoan hm = new HomeLoan(id, d);
//            hm.setLoanType(s);
//            hm.setRepaymentFrequency(fr);
//            hm.setRoi(roi);
//            hm.setTenure(tenure);
//            hm.setMonthlyIncome(income);
//            hm.setMonthlyExpense(expense);
//            hm.setLoanDisbursalDate(da);
//
//            hm.calculateEmi();
//
//
//            hm.calculateEligibleLoanAmount();
//            double maxLoanAmount = hm.getMaxEligibleLoanAmount();
//            System.out.println("Your Maximum Eligible Loan Amount for Home Loan is :" + maxLoanAmount);
//
//            System.out.println("Enter Property Size");
//            hm.setPropertySize(sc.nextInt());
//
//            System.out.println("Enter property Value");
//            hm.setPropertyValue(sc.nextDouble());
//
//            System.out.println("Enter Builder Name");
//            hm.setBuilderName(sc.nextLine());
//
//            double ltv = hm.loanToValueRatio();
//            ltv = ltv * 100;
//            System.out.println("Your Loan To Value Ratio is " + ltv);
//
//
//            if (ltv <= 80) {
//                Loan.LoanStatus ls = Loan.LoanStatus.approved;
//                hm.calculateEmi();
//                double emi = hm.getEmiPerMonth();
//                System.out.println("Your Emi are :" + emi);
//
//                hm.generateRepaymentSchedule();
//            } else {
//
//                System.out.println("Not Eligible for Laon");
//            }
//
//        } else if (s.equalsIgnoreCase("vehicle loan")) {
//            VehicleLoan vl = new VehicleLoan();
//
//            vl.setLoanType(s);
//            vl.setRepaymentFrequency(fr);
//            vl.setRoi(roi);
//            vl.setTenure(tenure);
//            vl.setMonthlyIncome(income);
//            vl.setMonthlyExpense(expense);
//            vl.setLoanDisbursalDate(da);
//
//            vl.calculateEmi();
//
//
//            vl.calculateEligibleLoanAmount();
//            double maxLoanAmount = vl.getMaxEligibleLoanAmount();
//            System.out.println("Your Maximum Eligible Loan Amount for Vehicle Loan is :" + maxLoanAmount);
//
//            System.out.println("Enter Asset Value");
//            vl.setAssetValue(sc.nextDouble());
//
//            double ltvr = vl.loanToValueRatio();
//            ltvr = ltvr * 100;
//            System.out.println("Your Laon to value Ratio is :" + ltvr);
//
//            if (ltvr <= 80) {
//                System.out.println("Enter Vehicle Category");
//                vl.setVehicleCategory(sc.nextLine());
//
//                System.out.println("Enter Model No");
//                vl.setVehiclemodelNo(sc.nextLine());
//
//                System.out.println("Enter Manufacturer");
//                vl.setManufacturer(sc.next());
//
//                System.out.println("Enter Year Of Manufacture");
//                vl.setYearOfManufacture(sc.nextInt());
//
//                Loan.LoanStatus ls = Loan.LoanStatus.approved;
//                vl.calculateEmi();
//                double emi = vl.getEmiPerMonth();
//                System.out.println("Your Emi are :" + emi);
//
//                vl.generateRepaymentSchedule();
//
//            } else {
//                System.out.println("You Are Not Eligible For Loan");
//            }
//
//        } else if (s.equalsIgnoreCase("personal loan")) {
//            PersonalLoan pl = new PersonalLoan(id, d);
//
//            pl.setLoanType(s);
//            pl.setRepaymentFrequency(fr);
//            pl.setRoi(roi);
//            pl.setTenure(tenure);
//            pl.setMonthlyIncome(income);
//            pl.setMonthlyExpense(expense);
//            pl.setLoanDisbursalDate(da);
//
//            pl.calculateEmi();
//
//            System.out.println("Enter Your Qualifacation");
//            pl.setQualification(sc.nextLine());
//
//            System.out.println("Enter Your Work Experience");
//            pl.setWorkExperience(sc.nextDouble());
//
//            if (pl.getWorkExperience() >= 2) {
//                pl.calculateEligibleLoanAmount();
//                double maxLoanAmount = pl.getMaxEligibleLoanAmount();
//                System.out.println("Your Maximum Eligible Loan Amount for Personal Loan is :" + maxLoanAmount);
//
//                pl.generateRepaymentSchedule();
//
//
//            } else {
//                System.out.println("Please Enter Correct Loan Type");
//            }
//
//
//        }
//    }
//}
