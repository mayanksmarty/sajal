package customerLoan;

import java.time.LocalDate;

public class HomeLoan extends SecuredLoan {
    String builderName;
    int propertySize;
    double propertyValue;
    static int i;




    public HomeLoan(double loanAmount,
                    double roi, int tenure, String typeOfLoan,
                    int repaymentFrequency, double monthlyIncome,
                    String builderName, int propertySize, double propertyValue) {

        super(loanAmount,roi,tenure,typeOfLoan,repaymentFrequency,monthlyIncome);
        this.builderName=builderName;
        this.propertySize=propertySize;
        this.propertyValue=propertyValue;

    }


    public String getBuilderName() {
        return builderName;
    }

    public void setBuilderName(String builderName) {
        this.builderName = builderName;
    }

    public int getPropertitySize() {
        return propertySize;
    }

    public void setPropertySize(int propertySize) {
        this.propertySize = propertySize;
    }

    public double getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(double propertyValue) {
        this.propertyValue = propertyValue;
    }

    @Override
    double loanToValueRatio() {
        double ltv= (getLoanAmount()/getPropertyValue());

        if(ltv*100<=80)
        {
            loanStatus=LoanStatus.approved;
        }
        else{
            loanStatus=LoanStatus.reject;
        }
        return ltv;
    }
}

