package customerLoan;

public class Shaurya {
    public static void main(String[] args) {
        int number=0;
        System.out.println(number++);
    }
}
