package practice;

public class Test {
    public static void main(String[] args) {
        RepaySchedule rs=new RepaySchedule();
        rs.generateRepaymentSchedule();
    }
}
