package practice;

import java.time.LocalDate;

public class RepaySchedule {



    public double calculateEmi(double loanAmount,int tenure,int repaymentFrequency, double roi)
    {
        int t=(int) tenure* repaymentFrequency;
        double r=roi/100;
        double power=Math.pow((1 + r/repaymentFrequency), t);
        double residual=0;
        double emiPerMonth=((loanAmount*r/repaymentFrequency)-((residual*r/repaymentFrequency)/power))/(1-1/power);

        System.out.println(emiPerMonth);
        return emiPerMonth;

    }


    void generateRepaymentSchedule()
    {
        RepaySchedule rs=new RepaySchedule();
        double interestCompo;
        double openBalance=100000;

        System.out.println("openbalance "+openBalance);
        double principalCompo=0                                                                                                                                                                      ;
        double r=10/100;
        int t= 2* 12;
        System.out.println(t);

        double power=Math.pow((1 + r/12), t);
        double residual=0;

        double installment=((100000*r/1200)-((residual*r/12)/power))/(1-1/power);


        System.out.println("installment is :"+installment);
        double n=2*12;
        //LocalDate duDate=
        for(int i=1;i<=n;i++)
        {

            System.out.println();
            System.out.println();System.out.println();System.out.println();System.out.println();System.out.println();




            System.out.println("Installment No: " +(100+i));
            openBalance-=principalCompo;
            System.out.println("Opening Balance: "+openBalance);
            System.out.println("Insatllment: "+installment);
            interestCompo=(10/1200)*openBalance;
            System.out.println("Interest Component: "+interestCompo);
            principalCompo=installment-interestCompo;
            System.out.println("Principal Component: "+principalCompo);

        }
    }

}
