class Thr implements Runnable {
    public
    void run()
    {
        System.out.println("Run");
    }
} class Myclass {
    public
    static void main(String[] args)
    {
      // Thr t1 = new Thr();
        Thread t = new Thread();
        t.start();
        System.out.println("Main");
    }
}
