
package ASS2Q1;
import java.util.Scanner;
import java.time.LocalDate;
public class Customer {
    private int customerId;
    private String custName;
    private  LocalDate dob;
    private String mobNo;
    private String email;
    private double monthlyIncome;
    private String profession;
    private double totalMonthlyExpenses;
    private String  designation;
    private String companyName;

    public Customer(int customerId, String custName) {
        this.customerId = customerId;
        this.custName = custName;
    }
    private Customer(){}
    public static Customer cust=null;
    public static Customer objectCreation()
    {
        if(cust==null) {
            cust = new Customer();
            cust.customerId=1;
            cust.custName="sajal";
            cust.dob=LocalDate.now();
            cust.mobNo="954565454";

        }
        return cust;
    }





    public LocalDate getDob() {
        return dob;
    }

    public String getCompanyName()
    {
        return(companyName);
    }
    public double getTotalMonthlyExpenses()
    {
        return totalMonthlyExpenses;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setTotalMonthlyExpenses(double totalMonthlyExpenses) {
        this.totalMonthlyExpenses = totalMonthlyExpenses;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }



    public int getid()
    {
        return(customerId);
    }
    public String getName()
    {
        return(custName);
    }
    public String getMobNo()
    {
        return(mobNo);
    }
    public String getEmail()
    {
        return(email);
    }
    public double getMonthlyIncome()
    {
        return(monthlyIncome);
    }
    public String getProfession()
    {
        return(profession);
    }
    public String getDesignation()
    {
        return(designation);
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", custName='" + custName + '\'' +
                ", dob=" + dob +
                ", mobNo='" + mobNo + '\'' +
                ", email='" + email + '\'' +
                ", monthlyIncome=" + monthlyIncome +
                ", profession='" + profession + '\'' +
                ", totalMonthlyExpenses=" + totalMonthlyExpenses +
                ", designation='" + designation + '\'' +
                ", companyName='" + companyName + '\'' +
                '}';
    }

    double dbr()
     {
         return(totalMonthlyExpenses/monthlyIncome);
     }

     double maxEligibleEmi()
     {

         return(0.5*(monthlyIncome-0.2*monthlyIncome));
     }

}
