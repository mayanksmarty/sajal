import java.util.ArrayList;
import java.util.Iterator;
import ASS2Q1.Customer;



public class Example {
    public static void main(String args[])
    {
        ArrayList l1=new ArrayList(11);

        l1.add("ajay");
        l1.add("rahul");
        l1.add("sajal");
        l1.add(1);
        Customer c1=Customer.objectCreation();
        Customer c2=Customer.objectCreation();
        l1.add(c1);
        l1.add(33.5f);
        l1.add(22);
        l1.add(c2);
        l1.add(1,23);
        Iterator it=l1.iterator();
        while(it.hasNext())
        {
            System.out.println(it.next());
        }
    }


}
