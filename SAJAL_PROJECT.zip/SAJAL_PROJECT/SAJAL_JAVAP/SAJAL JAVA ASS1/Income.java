class Income
{
private double salary;
private double pension;
private double shop_income;
double totalincome;
public void set_data(double s,double p,double shop)
{
salary=s;
pension=p;
shop_income=shop;
}

public void show_data()
{
System.out.println(salary);
System.out.println(pension);
System.out.println(shop_income);
totalincome=salary+pension+shop_income;
}
}
