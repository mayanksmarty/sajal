import java.util.Scanner;
import java.lang.Math;
public class Q6ass1 {
    public static void main(String[] args)
    {
        double loanAmount;
        double openingBalance;
        double rateOfInterest;
        int noOfPaymentsInYear;
        int  tenure;
        double interestCompo;
        double principalCompo;
        Scanner obj= new Scanner(System.in);

        System.out.println("Enter Loan Amount");
        loanAmount=obj.nextDouble();
        openingBalance=loanAmount;
        System.out.println("Enter Rate Of Interest");
        rateOfInterest=obj.nextDouble();
        rateOfInterest=(1/100)*rateOfInterest;
        System.out.println("How Many Payments Do You Wants In A Year");
        noOfPaymentsInYear=obj.nextInt();
        System.out.println("In How Many year You Would Repay Loan");
        tenure=obj.nextInt();
        tenure=tenure*noOfPaymentsInYear;
        double residual=0;
        double power=Math.pow((1 + rateOfInterest / noOfPaymentsInYear), tenure);
        double emi=((loanAmount*rateOfInterest/noOfPaymentsInYear)-((residual*rateOfInterest/noOfPaymentsInYear)/power))/(1-1/power);
       for(int i=1;i<=tenure;i++)
       {
           interestCompo=rateOfInterest*(1/12)*openingBalance;
           System.out.println("Interest Component: "+interestCompo);
           principalCompo=emi-interestCompo;
           System.out.println("Principal Component: "+principalCompo);
           openingBalance-=principalCompo;
       }
    }

}
