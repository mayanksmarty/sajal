class Dbr
{
public static void main(String[]args)
{
Expences exp=new Expences();
exp.set_data(15000.0,10000.0,12000.0,30000.0);
exp.show_data();
Income i1=new Income();
i1.set_data(55000.0,25000.0,15000.0);
i1.show_data();
double DBR=exp.totalexpence/i1.totalincome;
System.out.println("The DBR of person is" + DBR);

double per=DBR*100;

if(per<=36)
System.out.println("Eligible for loan");
else
{
System.out.println("The person is not eligible for this loan");
}
}
}