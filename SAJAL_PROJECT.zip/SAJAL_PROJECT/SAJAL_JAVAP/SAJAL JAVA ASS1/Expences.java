class Expences
{

private double rent;
private double car_loan_emi;
private double edu_loan_emi;
private double credit_card_payment;
double totalexpence;

public void set_data(double r,double c,double e,double cr)
{
rent=r;
car_loan_emi=c;
edu_loan_emi=e;
credit_card_payment=cr;
}
public void show_data()
{
System.out.println(rent);
System.out.println(car_loan_emi);
System.out.println(credit_card_payment);
System.out.println(edu_loan_emi);
   totalexpence=rent+car_loan_emi+edu_loan_emi+credit_card_payment;
}
}
