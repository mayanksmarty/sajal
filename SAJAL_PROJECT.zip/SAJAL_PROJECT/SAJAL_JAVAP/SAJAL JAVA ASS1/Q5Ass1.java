import java.sql.SQLOutput;
import java.util.Scanner;
import java.lang.Math;
public class Q5Ass1
{
    public static void main(String[] args)
    {
         double installmentNo;
         double openingBal;
        double interestCompo;
         double principleCompo=0;
        Scanner obj = new Scanner(System.in);
        System.out.println("Enter Opening balance");
        openingBal=obj.nextDouble();
        System.out.println("Enter interest rate");
        double interestRate=obj.nextDouble();
        interestRate=(0.01)*interestRate;

        System.out.println(interestRate);
        System.out.println("how many installments do you want to pay in a year");
        int noOfPaymentInYear=obj.nextInt();
        System.out.println("In how many year you want to repay loan");
        int tenure=obj.nextInt();
        tenure=tenure*noOfPaymentInYear;
        double power=Math.pow((1 + interestRate / noOfPaymentInYear), tenure);
        System.out.println(power);
        double loanAmount=openingBal;
        double residual=0;
        double installment=((loanAmount*interestRate/noOfPaymentInYear)-((residual*interestRate/noOfPaymentInYear)/power))/(1-1/power);
        System.out.println(installment);
        for(int i=1;i<=tenure;i++)
        {
            System.out.println("Installment No: " +i);
            openingBal=openingBal-principleCompo;
            System.out.println("Opening Balance: "+openingBal);
            interestCompo=openingBal*(interestRate/12);
            System.out.println("Interest Component: "+interestCompo);
            principleCompo=installment-interestCompo;
            System.out.println("Principle Component: "+principleCompo);
            System.out.println("Installment In Month: "+installment);
        }
    }
}













