class  Ltv
{
private static double  loan_amount, LTVR, property_value;
public static void main(String[] args)
{
  loan_amount=1000000;
  property_value=5000000;
  LTVR=(loan_amount/property_value)*100;
System.out.println(LTVR+"%");
if(LTVR<=80)
System.out.println("You are eligible for loan");
else
{
System.out.println("You are not eligible for loan");
}
}
}