import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/Customer")
public class Customer extends HttpServlet {
}
