import java.sql.*;
import java.time.LocalDate;

public class DAOSignUp {
    PreparedStatement psInsertCustomer;
    PreparedStatement psInsertUser;
    PreparedStatement psSelectUser;
    PreparedStatement psSelectCustomer;

    DAOSignUp() {
        Connection con = Connect.getConnection();
        try {
            psInsertCustomer = con.prepareStatement("insert into Customer_St values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
            psInsertUser = con.prepareStatement("insert into User_St1  values(?,?,?,?,?,?,?,?,?,?)");

            psSelectCustomer = con.prepareStatement("select UserId , Password from  Customer_Ut where UserId = ? and Password =? ");
            psSelectUser = con.prepareStatement("select UserId , Password from  User_Ut where UserId = ? and Password =? ");
            //psSelect = con.prepareStatement("select * from  ");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    int insertObject(Customers customers) {
        int r = 0;

        try {
            psInsertCustomer.setString(1, customers.getFirstName());
            psInsertCustomer.setString(2, customers.getLastName());
            psInsertCustomer.setString(3, customers.getPassword());
            psInsertCustomer.setString(4, customers.getEmail());
            psInsertCustomer.setInt(5, customers.getAge());
            psInsertCustomer.setLong(6, customers.getContactNo());
            psInsertCustomer.setString(7, customers.getGender());
            psInsertCustomer.setDate(8, Date.valueOf(customers.getDateOfBirth()));
            psInsertCustomer.setString(9,customers.getUserId());
            psInsertCustomer.setString(10,customers.getProfession());
            psInsertCustomer.setString(11,customers.getDesignation());
            psInsertCustomer.setString(12,customers.getCompanyName());
            psInsertCustomer.setDouble(13,customers.getMonthlyIncome());
            psInsertCustomer.executeUpdate();
            r = 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }


    int insertUser(Users users) {
        int r = 0;

        try {
            psInsertUser.setString(1, users.getFirstName());
            psInsertUser.setString(2, users.getLastName());
            psInsertUser.setString(3, users.getPassword());
            psInsertUser.setString(4, users.getEmail());
            psInsertUser.setInt(5, users.getAge());
            psInsertUser.setLong(6, users.getContactNo());
            psInsertUser.setString(7, users.getGender());
            psInsertUser.setDate(8, Date.valueOf(users.getDateOfBirth()));
            psInsertUser.setString(9, users.getUserId());
            psInsertUser.setString(10, users.getRole());
            psInsertUser.executeUpdate();
            r = 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }




    int selectCustomer(String userid, String Password) {
        Connection con = null;
        int flag = 0;
        try {
            con = Connect.getConnection();
            psSelectCustomer.setString(1, userid);
            psSelectCustomer.setString(2, Password);
            ResultSet rs = psSelectCustomer.executeQuery();
            while (rs.next()) {
                String id = rs.getString(1);
                String pass = rs.getString(2);
                if (id.equals(userid) && pass.equals(Password)) {
                    flag = 1;
                    break;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    int selectUser(String userid, String Password) {
        Connection con = null;
        int flag = 0;
        try {
            con = Connect.getConnection();
            psSelectUser.setString(1, userid);
            psSelectUser.setString(2, Password);
            ResultSet rs = psSelectUser.executeQuery();
            while (rs.next()) {
                String id = rs.getString(1);
                String pass = rs.getString(2);
                if (id.equals(userid) && pass.equals(Password)) {
                    flag = 1;
                    break;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }
}






//    int insertUser (String name , String password , String email, String contact , int age , Date dob, String gender ,  String role) {
//        int r= 0;
//        Connection con = null;
//        try {
//            con = Connect.getConnection();
//            psInsertCustomer.setString(1, name);
//            psInsertCustomer.setString(2, password);
//            psInsertCustomer.setString(3, email);
//            psInsertCustomer.setString(4, contact);
//            psInsertCustomer.setInt(5, age);
//            psInsertCustomer.setDate(6, dob);
//            psInsertCustomer.setString(7, gender);
//            psInsertCustomer.setString(8, role);
//
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                con.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//        return r;
//    }

//    Employee select(int id){
//        Connection con = null;
//        try{
//            con = Connect.getConnection();
//            psSelect.setInt(1,id);
//            ResultSet rs = psSelect.executeQuery();
//            if(rs.next()){
//                int i = rs.getInt(1);
//                String fn = rs.getString(2);
//                String ln = rs.getString(3);
//                Employee em = new Employee(i, fn, ln);
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        finally{
//            try {
//                con.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//        return em;
//    }








