import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;

@WebServlet("/LoginServlet.SignUp.html")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {


        resp.setContentType("text/html");
        String firstName = req.getParameter("firstname");
        String lastName = req.getParameter("lastname");
        String password = req.getParameter("pass");
        String emailId = req.getParameter("email");
        String  age = req.getParameter("age");
        LocalDate dateOfBirth = LocalDate.parse(req.getParameter("dob"));
        String contact = req.getParameter("contact");
        String gender = req.getParameter("gender");
        String usertype = req.getParameter("R1");

        String userId = usertype.substring(0,4)+firstName.substring(0,4)+lastName.substring(0,4);


        PrintWriter out = resp.getWriter();

        DAOSignUp daoSignUp = new DAOSignUp();
        if (usertype.equals("Customer")) {
            String  proffesion = req.getParameter("Profession");
            String  designation  = req.getParameter("Designation");
            String  compnayName  = req.getParameter("CompanyName");
            String  monthlyIncome = req.getParameter("MonthlyIncome");


            Customers customers = new Customers(firstName,lastName,gender,password,emailId,Integer.parseInt(age),dateOfBirth,
                    Long.parseLong(contact),userId,proffesion,
                    designation,compnayName,Double.parseDouble(monthlyIncome));
            daoSignUp.insertObject(customers);

            out.println("<html> <body>");
            out.println("User Id generated is : "+userId);




            RequestDispatcher rd = req.getRequestDispatcher("Login.html");
            rd.include(req,resp);

            out.println("</body></html>");

        }

        else
        {
            String role = req.getParameter("Role");
            Users user = new Users(firstName,lastName,password,emailId,Integer.parseInt(age),
            dateOfBirth,Long.parseLong(contact), gender,role,userId);
            daoSignUp.insertUser(user);



            out.println("<html> <body>");
            out.println("User Id generated is : "+userId);




            RequestDispatcher rd = req.getRequestDispatcher("Login.html");
            rd.include(req,resp);


            out.println("</body></html>");


        }



    }
}


