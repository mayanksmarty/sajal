package mvc;


import basic.Employee;

public class Presentation {
    private Service ser;

    public Presentation() {
        System.out.println("Presentation Constructor");
    }

    public Service getSer() {
        return ser;
    }

    public void setSer(Service ser) {
        this.ser = ser;
    }

    public void insert(Employee ee)
    {
        ser.insert(ee);
    }
}
