package mvc;

import basic.Employee;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Dao {
public Dao(){
    System.out.println("Dao constructor");
}
    private DataSource dataSource;

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
PreparedStatement psInsert;
    PreparedStatement psSelect;
    public void insert(Employee e)
    {
        Connection con=null;
        int r=0;
        
        try
        {
            con=dataSource.getConnection();

            psInsert=con.prepareStatement("insert into sajal101 values(?,?,?,?)");

            psInsert.setString(1,e.getName());
            psInsert.setString(2,e.getEmpID());
            psInsert.setDouble(3, e.getSalary());
            psInsert.setString(4,e.getRole());

            r=psInsert.executeUpdate();



        }
        catch (SQLException en)
        {
          en.printStackTrace();
        }

        finally{
            try{
                con.close();
            }catch(SQLException em){
                em.printStackTrace();
            }

        }


    }


}
