package mvc;

import basic.Employee;

public class Service {

    private Dao d;

    public Service(){ }

    public Dao getD() {
        return d;
    }
public void insert(Employee ee)
{
    d.insert(ee);
}
    public void setD(Dao d) {
        this.d = d;
    }
}

