package basic;


import mvc.Presentation;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {

        ApplicationContext ctx = new AnnotationConfigApplicationContext(Configs.class);
        Employee empp=(Employee) ctx.getBean("getEmployee");
        Presentation p=(Presentation)ctx.getBean("getPresentation");
        p.insert(empp);



//        Employee emp = (Employee) ctx.getBean("empp4");
//        System.out.println(emp.getName());
//        System.out.println(emp.getEmpID());
//        System.out.println(emp.getSalary());
//        System.out.println(emp.getRole());
//        System.out.println(emp.getCompany());
//       // System.out.println(emp.getAdd());
//        Address ad=emp.getAdd();
//        System.out.println(ad.getState());
        //System.out.println(ad.getCity());

//        System.out.println();
//        System.out.println();
//        System.out.println();
//        System.out.println();
//Employee emp1=(Employee) ctx.getBean("empp");
//        System.out.println(emp1.getName());
//        System.out.println(emp1.getEmpID());
//        System.out.println(emp1.getSalary());
//        System.out.println(emp1.getRole());
//        System.out.println(emp1.getCompany());
//        System.out.println(emp1.getAdd());

       // System.out.println(emp1.toString());
        System.out.println();
        System.out.println();
//
//        Employee emp3=(Employee) ctx.getBean("empp3");
//        System.out.println(emp3.getName());
//        System.out.println(emp3.getSalary());
//        System.out.println(emp3.getRole());
//        System.out.println(emp3.getAdd());
//        System.out.println(emp3.getAdd().getCity());


   /*     Presentation pr=(Presentation)ctx.getBean("present");
        System.out.println(pr.getSer());*/

//Employee emp4=(Employee) ctx.getBean("empp4");
//        System.out.println(emp4.getName());
//        System.out.println(emp4.getEmpID());
//        System.out.println(emp4.getSalary());

    }


}
