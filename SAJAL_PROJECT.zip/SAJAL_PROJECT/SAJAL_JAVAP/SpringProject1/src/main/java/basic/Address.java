package basic;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Map;

public class Address {
private List<String> city;
private Map<Integer,String> state;

public Address()
{
    System.out.println("Address Constructor");

}


    public Address(List<String> city, Map<Integer, String> state) {
        this.city = city;
        this.state = state;
    }

    public List<String> getCity() {
        return city;
    }

    public void setCity(List<String> city) {
        this.city = city;
    }

    public Map<Integer, String> getState() {
        return state;
    }

    public void setState(Map<Integer, String> state) {
        this.state = state;
    }


    @Override
    public String toString() {
        return "Address{" +
                "city=" + city +
                ", state=" + state +
                '}';


    }

}

