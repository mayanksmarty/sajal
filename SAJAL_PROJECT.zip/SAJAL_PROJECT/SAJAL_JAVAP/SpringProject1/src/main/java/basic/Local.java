package basic;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Local {

    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("/Spring.xml");
        Address address = (Address)ctx.getBean("custadd");

        System.out.println(address.getCity()+" "+address.getState());

    }
}

