package basic;

import basic.Employee;
import mvc.Dao;
import mvc.Presentation;
import mvc.Service;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.sql.DriverManager;
import java.util.Map;

@Configuration
public class Configs {


//
//    public DataSource getDataSource()
//    {
//        DriverManagerDataSource  datasource=new DriverManagerDataSource();
//    }
 @Bean(autowire= Autowire.BY_TYPE)
public Presentation getPresentation(){
    return new Presentation();
}
    @Bean(autowire=Autowire.BY_TYPE)
    public Service getpreservice(){
     mvc.Service service = new mvc.Service();
      return service;

    }

    @Bean
    public Employee getEmployee()
{
    Employee em=new Employee();
    return em;
}
@Bean(autowire=Autowire.BY_TYPE)
public Dao getDao()
{
    return new Dao();
}

}
