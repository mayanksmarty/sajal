package basic;

import java.sql.*;

public class Database {


    public static void main(String[] args) throws ClassNotFoundException, SQLException {



        String url ="jdbc:oracle:thin:@10.1.50.198:1521:orcl";
        String user="sh";
        String password ="sh";

        // dRiver Load
        Class.forName("oracle.jdbc.driver.OracleDriver");

        // Connection maintain

        Connection conn = DriverManager.getConnection(url, user, password);
        // Statement ya prepared staetment ;

        // Statement statement = connection.createStatement();

        String query ="insert into sajal101 values (?,?)";

        PreparedStatement preparedStatement = conn.prepareStatement(query);
        preparedStatement.setString(1,"NA1001");
        preparedStatement.setString(2,"sajal");


        int x = preparedStatement.executeUpdate();

        if(x != 0 )
        {
            System.out.println("Rows inserted "+x);
        }
        else
        {
            System.out.println("No data inserted");
        }

        String query1 ="insert into sajal101 values (?,?)";
        PreparedStatement pr1= conn.prepareStatement(query1);
        pr1.setString(1,"1001");
        pr1.setString(2,"mittal");

        int x1 = preparedStatement.executeUpdate();

        if(x1 != 0 )
        {
            System.out.println("Rows inserted "+x1);
        }
        else
        {
            System.out.println("No data inserted ");
        }

        String query2="select * from sajal101";
        PreparedStatement pr2=conn.prepareStatement(query2);
        ResultSet rs=pr2.executeQuery();

       while (rs.next()) {
           System.out.println(rs.getString(1) + " " + rs.getString(2));

       }



//        int x = preparedStatement.executeUpdate();
//
//        if(x != 0 )
//        {
//            System.out.println("Rows inserted "+x);
//        }
//        else
//        {
//            System.out.println("No data inserted ");
//        }


        conn.close();

    }
}
