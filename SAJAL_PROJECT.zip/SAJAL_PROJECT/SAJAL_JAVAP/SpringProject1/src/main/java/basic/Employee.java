package basic;

import javax.annotation.Resource;

public class Employee {
    private String name;
    private String empID;
    private double salary;
    private String company;
    private String role;
@Resource
    private Address abc;

    public Employee() {

        System.out.println("Employee constructor");
    }

    public Employee(String name, String empID, double salary, String company, String role, Address abc) {
        this.name = name;
        this.empID = empID;
        this.salary = salary;
        this.company = company;
        this.role = role;
        this.abc = abc;
    }

    public Employee(String name, String empID, Address abc) {
        this.name = name;
        this.empID = empID;
        this.abc = abc;
    }

    public Employee(double sal, String id, String nam)
{
    this.salary=sal;
    this.empID=id;
    this.name=nam;
}
public Employee(String name,String empID)
{
    this.name=name;
    this.empID=empID;
}
public Employee(String name,String empID,double salary)
{

 this.name=name;
 this.empID=empID;
 this.salary=salary;
}

    public Address getAdd() {
        return abc;
    }

    public void setAdd(Address add) {
        abc = add;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void calculateExperience()
    {
        System.out.println("Experience Function called");
    }

    public void ceoOfCompany()
    {
        System.out.println("CEO of Company is ABC");
    }
    public void calculateSalary()
    {
        System.out.println("Calculate salary is called");
    }



//    public String toString() {
//        return "Employee{" +
//                "add=" + add +
//                '}';
//    }
}

