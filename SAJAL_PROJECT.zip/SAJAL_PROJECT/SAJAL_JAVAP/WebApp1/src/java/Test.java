import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/html.nsbt")
public class Test extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        out.println("<html> <head> <title> Welcome Here </title> </head> <body> <h1> Successfully Login </h1> </body> </html>");

        resp.setContentType("text/html");
        PrintWriter pout=resp.getWriter();
        pout.println("<html> <head> <title> Welcome Here </title> </head> <body> <h1> we will provide complete registration details </h1> </body> ");

    }
}
