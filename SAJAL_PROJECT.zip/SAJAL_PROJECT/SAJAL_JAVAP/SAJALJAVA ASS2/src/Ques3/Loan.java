package Ques3;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.lang.Math;
import java.time.temporal.ChronoUnit;
public class Loan {

    private int loanId;
private String loanType;
private double loanAmount;
private double tenure;
private double roi;
private double emiPerMonth;
private String loanStatus;
private LocalDate loanDisbursalDate;
private double maxEligibleLoanAmount;
private  int repaymentFrequency;
private double monthlyIncome;
static int count=0;



    public Loan( String loanType,double loanAmount) {
        this.loanId = ++count;
        this.loanType = loanType;
        this.loanAmount=loanAmount;
    }

    Scanner obj=new Scanner(System.in);
        public double getEmiPerMonth() {
            return emiPerMonth;
        }

        public void setEmiPerMonth(double emiPerMonth) {
            this.emiPerMonth = emiPerMonth;
        }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }


        public double getMonthlyIncome() {
            return monthlyIncome;
        }

    public int getLoanId() {
        return loanId;
    }



    public String getLoanType() {
        return loanType;
    }



    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getTenure() {
        return tenure;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public double getRoi() {
        return roi;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }

    public String isLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    public LocalDate getLoanDisbursalDate() {
        return loanDisbursalDate;
    }

    public void setLoanDisbursalDate(LocalDate loanDisbursalDate) {
        this.loanDisbursalDate = loanDisbursalDate;
    }

    public void setMaxEligibleLoanAmount(double maxEligibleLoanAmount) {
        this.maxEligibleLoanAmount = maxEligibleLoanAmount;
    }

    public double getMaxEligibleLoanAmount() {
        return maxEligibleLoanAmount;
    }

    public void setRepaymentFrequency(int repaymentFrequency) {
        this.repaymentFrequency = repaymentFrequency;
    }
    public void calculateEmi()
    {
        int t=(int) tenure* repaymentFrequency;
        double r=roi/100;
        double power=Math.pow((1 + r/repaymentFrequency), t);
        double residual=0;
         emiPerMonth=((loanAmount*r/repaymentFrequency)-((residual*r/repaymentFrequency)/power))/(1-1/power);
        setEmiPerMonth(emiPerMonth);
    }
    void generateRepaymentSchedule()
    {
        double interestCompo;
        double openBalance=loanAmount;
        double principalCompo=0;
        double r=roi/100;
        int t=(int) tenure* repaymentFrequency;
        double power=Math.pow((1 + r/repaymentFrequency), t);
        double residual=0;

        double installment=((loanAmount*r/repaymentFrequency)-((residual*r/repaymentFrequency)/power))/(1-1/power);

        System.out.println(installment);
        double n=tenure*repaymentFrequency;
        for(int i=1;i<=n;i++)
        {

            System.out.println();
            System.out.println();System.out.println();System.out.println();System.out.println();System.out.println();




            System.out.println("Installment No: " +(100+i));
            openBalance-=principalCompo;
            System.out.println("Opening Balance: "+openBalance);
            System.out.println("Insatllment: "+installment);
             interestCompo=(roi/1200)*openBalance;
            System.out.println("Interest Component: "+interestCompo);
            principalCompo=installment-interestCompo;
            System.out.println("Principal Component: "+principalCompo);

        }
    }

   public LocalDate calculateDueDate(){

       System.out.println("Enter the last repayment date in dd/mm/yyyy format");
       String repayDate=obj.next();
       DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
       LocalDate lastRepaymentDate=LocalDate.parse(repayDate,formatter);
       LocalDate dueDate=lastRepaymentDate.plusMonths(1);
       return(dueDate);



  }

    @Override
    public String toString() {
        return "Loan{" +
                "loanId=" + loanId +
                ", loanType='" + loanType + '\'' +
                ", loanAmount=" + loanAmount +
                ", tenure=" + tenure +
                ", roi=" + roi +
                ", emiPerMonth=" + emiPerMonth +
                ", loanStatus='" + loanStatus + '\'' +
                ", loanDisbursalDate=" + loanDisbursalDate +
                ", maxEligibleLoanAmount=" + maxEligibleLoanAmount +
                ", repaymentFrequency=" + repaymentFrequency +
                ", monthlyIncome=" + monthlyIncome +
                '}';
    }

    void calculateLatePenalty()
    {

        LocalDate repaymentDate=LocalDate.now();

        LocalDate dueDate=calculateDueDate();
        if(repaymentDate.equals(dueDate))
        {
            System.out.println("There is no penalty as your payment is in time \nThank You");

        }
        else
        {
            double n=85.65;
            long noOfDaysBetween = ChronoUnit.DAYS.between(dueDate, repaymentDate);

            double penalty=n*noOfDaysBetween;
            System.out.println("Your penalty, due to late payment is "+penalty);

        }



    }
   public void calculateEligibleLoanAmount()
    {
        double r=roi/1200;
        double e=0.5*(monthlyIncome-0.2*monthlyIncome);
        int t=7;
        double pow=Math.pow((1+r),t);
       double max= e * (pow -1 )/ (r * (pow));
        setMaxEligibleLoanAmount(max);
    }
}
