package Ques3;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
class Ques3main {
    public static void main(String[] args) {

        Scanner obj=new Scanner(System.in);
        System.out.println("Enter Loan Id");
        int lid=obj.nextInt();
        System.out.println("Enter Loan Amount");
        double amt=obj.nextDouble();
        Loan l1=new Loan("education",amt);


        System.out.println("Loan Details: ");
       LocalDate date=LocalDate.now();
        l1.setLoanDisbursalDate(date);



        System.out.println("Enter Tenure");
        l1.setTenure(obj.nextInt());

        System.out.println("Enter Rate Of interest");
        l1.setRoi(obj.nextDouble());

        System.out.println("Enter Repayment frequency");
        l1.setRepaymentFrequency(obj.nextInt());

        System.out.println("Enter Your Monthly Income");
        l1.setMonthlyIncome(obj.nextDouble());

        System.out.println();
        System.out.println();
        System.out.println();

        l1.calculateEligibleLoanAmount();
        System.out.println("Your max eligible Loan Amount Is: "+l1.getMaxEligibleLoanAmount());

        System.out.println();
        System.out.println();
        System.out.println();

        l1.calculateEmi();
        System.out.println("Your EMI is: "+l1.getEmiPerMonth());
        System.out.println();
        System.out.println();
        System.out.println();System.out.println();

        System.out.println("Repayment Schedule: ");
        l1.generateRepaymentSchedule();

        l1.calculateLatePenalty();









    }

}



