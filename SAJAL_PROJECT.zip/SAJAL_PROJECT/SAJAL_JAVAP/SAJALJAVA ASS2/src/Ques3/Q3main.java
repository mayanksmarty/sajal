package Ques3;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Q3main {
    public static void main(String[] args)
    {
        Scanner obj=new Scanner(System.in);
        System.out.println("Enter  Name :");
        String name=obj.nextLine();

        System.out.println("Enter Customer Id ");
        int id=obj.nextInt();

        Customer sajal=new Customer(name);
        LocalDate dob;
        System.out.println("Enter your DOB in dd/mm/yyyy format");
        String date=obj.next();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        dob=LocalDate.parse(date,formatter);
        System.out.println(date+" "+dob);

        sajal.setDob(dob);

        System.out.println("Please Fill Your Details :");

        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");

        System.out.println("Enter Your Email Id: ");
        sajal.setEmail(obj.nextLine());
        System.out.println("Tell me Your Profession:  ");
        sajal.setProfession(obj.nextLine());
        System.out.println("Pls Tell me Your Designation ");
        sajal.setDesignation(obj.nextLine());
        System.out.println("What is Your Company Name");
        sajal.setCompanyName(obj.nextLine());


        System.out.println("Enter Your Mob No :");
        sajal.setMobNo(obj.nextLine());

        System.out.println("Tell me Your Monthly Income");
        sajal.setMonthlyIncome(obj.nextDouble());
        System.out.println("Please Mention Your Monthly Expences:");
        sajal.setTotalMonthlyExpenses(obj.nextDouble());

        System.out.println(sajal);

        System.out.println("your id:"+sajal.getid());
        System.out.println("your name is: "+sajal.getName());
        System.out.println("Mob no: "+sajal.getMobNo());
        System.out.println("email id:"+sajal.getEmail());
        System.out.println("Your Monthly Income is: "+sajal.getMonthlyIncome());
        System.out.println("You are in the profession of: "+sajal.getProfession());
        System.out.println("Your designation is: "+sajal.getDesignation());
        System.out.println("You are in: "+sajal.getCompanyName());
        System.out.println("Your Monthly Expenses are: "+sajal.getMonthlyIncome());
        System.out.println("DOB: "+sajal.getDob());



        double dbr=sajal.dbr();
        dbr*=100;
        System.out.println("DBR is: "+dbr);
        if(dbr<35)
        {
            System.out.println("You are perfectly eligible for the loan");
        }
        else{
            System.out.println("You are not eligible for the loan");
        }
        double maxEmi=sajal.maxEligibleEmi();
        System.out.println("Your maximum eligible Emi is:"+maxEmi);

    }



}
