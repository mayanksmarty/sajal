public class Student {

    private long rollNo;
    private String name;
    private String course;
    static private String country;

    public Student(long rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    public void setCourse(String course) {
        this.course = course;
    }

   static public void setCountry(String country) {
        Student.country = country;
    }

    public long getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }

    public static String getCountry() {
        return country;
    }

    @Override
    public String toString() {
        return "Student{" +
                "rollNo=" + rollNo +
                ", name='" + name + '\'' +
                ", course='" + course + '\'' +
                '}';
    }
}






