public class GeneralMain {

    public static void main(String[] args) {
        Student sajal=new Student(1614313067,"sajal");
        sajal.setCourse("Core JAVA");
       String co= sajal.getCourse();
       String na=sajal.getName();
       long roll=sajal.getRollNo();
       Student.setCountry("INDIA");
        System.out.println(sajal);
    }
}
