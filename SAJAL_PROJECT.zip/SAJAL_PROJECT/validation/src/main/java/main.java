public class main {
    public static void main(String[] args) {
        validation obj=new validation();
        System.out.println(obj.email("jhgjdgh@gmail@com"));
    }
}
