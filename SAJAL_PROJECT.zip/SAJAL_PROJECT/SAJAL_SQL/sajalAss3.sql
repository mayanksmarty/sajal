
create table DEPT2(Id  NUMBER(7), Name  varchar2(25));1

insert into dept2 values(select department_id department_name from department); 2

create table EMp2(Id  NUMBER(7),last_Name  varchar2(25), first_name varcahr2(25), dept_id number(7));3

Alter table EMp2 modify last_name varchar2(100); 4

select * from DBPT2; 
select * from eMp2; 5

create table employees2 as select employee_id "id", first_name, last_name, department_id dept_id from employees; 6

DROP table EMp2; 7


Alter table employee2 set unused column first_name;
desc employee2; 10


alter table emp2 modify id number(6) constraints my_emp_id_pk primaryry key; 11

create table product(product_no varcahr2(6) primary key,name varcahr2(20) not null,descryption varcahr2(30), qtyinhand varcha2(30), sellprice varcahr2(15), csotprice varcahr2(8) ,state varcahr2(15)); 12(a)


create table client(clientno varcahr2(6) primary key,name varchar2 not null,address1 varchar2(30),address2 varchar2(30),city varcahr2(15),pincode varcahr2(8),state vvarcahr2(15), productno varcahr2(6)  foreign key(productno) references product(productno)); 12(b)

alter table client add telephone number(10);
alter table product modify sellprice varchar2(10,2); 12(c)



                      DML
1) create table My_employee(id number(4),last_name varcahr2(25),first_name varcahr2(25),userid varcahar2(8),salary number(9,2);

2)Desc My_employee;

3)inset into My_employee values(1,'patel','ralph','rpatel',895); 

4)insert into My_employees (id,last_name,first_name,userid,salary) values(2,'Dancs','Betty','bdancs',860);

5)select * from My_employees;

6)

7)

8)
insert into My_employee values(3,'biri',ben','bbiri',1100);
insert into My_employees values(4,'newman','chad','cnewman',750);

9) commit

10) update My_employee set last_name='Derxler' where id=1;

11) update My_mployee set salary=1000 where salary<900;

12) select * from My_employee;

13) delete from My_employee where first_name=Betty and last_name=Dancs;

14) select * from My_employee;

15)commit;

16)insert into My_employees(5,'Ropeburn','Auderey','aropebur',1550);

17)Select * from employees;


18)
 
19)delete from My_employees;

20)select * from My_employes;

21)rollback

22)select * from My_employees;

23) commit