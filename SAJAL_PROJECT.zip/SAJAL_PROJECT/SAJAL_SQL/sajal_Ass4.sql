select last_name,salary  from employees where salary > 12000; 1

select last_name,department_id from employees where employee_id=176; 2

select last_name, salary from employees where salary not between 5000 and 12000; 3 

select last_name,job_id,hire_date from employees where last_name in('Mathos','Taylor') order by hire_date asc; 4

select last_name, department_id from employess where department_id in(20,50) order by first_name asc; 5

select last_name,salary  monthly_salary from employees where (salary between 5000 and 12000) and department_id in(20,50); 6

select last_name from employees where last_name like '__a%'; 7

select last_name from employees where last_name like '%a%e%'; 8

select last_name,job_id,salary from employees where job_id in ('SA_REP','ST_CLERK') and salary not in (2500,3500,7000); 9


select last_name,salary,commission_pct from employees where commission_pct=0.2; 10

select last_name,round((sysdate-hire_date)/30,0) months_worked from employees order by (sysdate-hire_date)/30; 11

select last_name, hire_date,to_char(hire_date,'day') Day from employees order by to_char(hire_date,'day');//12

select l.location_id,l.street_address,l.city,l.state_province,d.country_name from locations l join countries d on l.country_id=d.country_id; 13

select last_name,department_id,department_name from employees; 14

select e.last_name,e.employee_id "EMP#" ,e.manager_id "MGR#",m.last_name from employees e  join employees m on e.manager_id=m.employee_id;15

select e.last_name,e.department_id,d.last_name colleague from employees e join employees d on e.department_id=d.department_id where e.employee_id<>d.demployee_id;16

select e.last_name,e.job_id,d.department_name,e.salary,j.grade_level from employees e join  department d on (e.department_id=d.department_id) join job_grades j on (e.salary between j.lowest_sal and j.highest_sal); 17

select e.last_name,d.department_name,l.city,l.state_province from employees e join departments d on (e.department_id=d.department_id) join locations l on d.location_id=l.location_id; 18

select e.employee_id,e.last_name,d.department_name,l.city,l.state_province from employees e join departments d  on e.department_id=d.department_id join locations l on d.location_id=l.location_id and e.last_name like "%a%"; 19

select last_name, salary from employees where salary<(select salary from employees where employee_id=182);20

select e.last_name,i.last_name from employees e  join employees i on e.manager_id=i.employee_id;  21

select j.job_title,d.department_name,e.last_name,j.start_date,j.end_date from employees e join department on e.employee d join job_history; doubt 22


select department_name,avg(salary),count(Commission_act) "No Of Employees" from employees group by department_name; error

select job_title,avg(salary) from employees group by job_title; doubt

select country

Write a query in SQL to display the country name, city, and number of those
departments where at leaste 2 employees are working.




select country_name,city,count(departments) g
















 







