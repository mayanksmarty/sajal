 select last_name,job_id,salary AS sal from employees; //1
 
 select * from job_grades; //2

 select employee_id,last_name, salary*12 Annual_Salary from employees;//3

 desc departments; //4

 select *from departments; //5 

 desc EMPLOYEES; 6
 
 select employee_id,last_name,job_id,hire_date as satartdate from employees; 7
 
 select distinct job_id from employees; 8
 
 select emp#,employee,job,hiredate from employees;//error 9
 
 select INITCAP(last_name),length(last_name) len from employees where last_name like 'J%' or last_name like 'A%' or last_name like 'M%'; 10
 
 select to_char(sysdate,'DD/MM/YYYY') date_ from dual; 11
 
 select employee_id,last_name,salary,salary+salary*0.155 Newsalary from employees; 12
  
 select employee_id,last_name,salary,salary+salary*0.155 Newsalary,salary,salary+salary*0.155-salary Increase from employees; 13
 
 select INITCAP(last_name),length(last_name) len from employees where last_name like 'J%' or last_name like 'A%' or last_name like 'M%';14
 
 select round(max(salary),2) MAx, round(min(salary),2) min, round(avg(salary),2) avg, round(sum(salary),2) sum from employees; 15
 
 select round(max(salary),2) MAx, round(min(salary),2) min, round(avg(salary),2) avg, round(sum(salary),2) sum from employees group by job_id; 16
 
 select last_name,salary,salary*3 dream_salary from employees; 17
 
 select last_name || ', ' || job_id Title from employees; 18
 
 select job_id, count(*) Nu from employees group by job_id; 19
 
 select to_char(hire_date,'monthdd, yyyy') from employees; 20
 
 select first_name, last_name, substr(first_name,1,1)||substr(last_name,-3,3)||'@nucleussoftware.com' from employees;//21
 
 select first_name , last_day(hire_date) from employees;//22

select first_name, round((sysdate-hire_date)/365,2) experience from employees;//23 

select first_name, round(sysdate-hire_date),0) experience from employees;//24

select distinct manager_id, count(*) manages from employees group by manager_id;//25


